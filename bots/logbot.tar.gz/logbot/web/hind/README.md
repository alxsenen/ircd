https://github.com/itfoundry/hind

```
This Font Software is licensed under the SIL Open Font License,
Version 1.1.

This license is available with a FAQ at http://scripts.sil.org/OFL
```
