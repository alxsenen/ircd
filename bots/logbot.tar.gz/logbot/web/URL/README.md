https://github.com/webcomponents/URL

```
Any copyright is dedicated to the Public Domain.
http://creativecommons.org/publicdomain/zero/1.0/
```
