# LogBot

> IRC logger and publisher.

https://logbot.info/

# About

LogBot is comprised of three main parts:

- `logbot-irc`: IRC bot that logs events to a queue
- `logbot-consumer`: Processes and stores queued events
- `logbot-web`: Mojolicous application for viewing logs online

# Maintainer

* glob (byron@glob.com.au)

# License

* MIT
